//
//  SJSettingViewController.h
//  SSJStaticTableViewDemo
//
//  Created by Sun Shijie on 2017/3/16.
//  Copyright © 2017年 Shijie. All rights reserved.
//

#import "SJStaticTableViewController.h"

@interface SJSettingViewController : SJStaticTableViewController

@end
