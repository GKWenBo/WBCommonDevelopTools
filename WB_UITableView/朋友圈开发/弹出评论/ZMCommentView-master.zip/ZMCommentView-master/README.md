# ZMCommentView
1、可扩展、可单独分离使用的弹出式评论列表，一般用于查看全部评论；

2、键盘弹出评论输入，自适应文字高度；

3、仅引入了Masonry做布局；

4、一句代码展示全部评论

有什么问题，可以再issues告知我，欢迎点小星星！


使用方式：

 [[ZMCusCommentManager shareManager] showCommentWithSourceId:nil];



<br>效果<br>
![示例图1](https://github.com/luckyxiangfeng/ZMCommentView/blob/master/ZMCommentView/ZMCommentView/Photo/photo_1.png)
![示例图2](https://github.com/luckyxiangfeng/ZMCommentView/blob/master/ZMCommentView/ZMCommentView/Photo/photo_2.png)
![示例图3](https://github.com/luckyxiangfeng/ZMCommentView/blob/master/ZMCommentView/ZMCommentView/Photo/photo_3.png)


