//
//  SJCustomCellsViewController.h
//  SSJStaticTableViewDemo
//
//  Created by Sun Shijie on 2017/3/18.
//  Copyright © 2017年 Shijie. All rights reserved.
//

#import "SJStaticTableViewController.h"

@interface SJCustomCellsViewController : SJStaticTableViewController

@end
