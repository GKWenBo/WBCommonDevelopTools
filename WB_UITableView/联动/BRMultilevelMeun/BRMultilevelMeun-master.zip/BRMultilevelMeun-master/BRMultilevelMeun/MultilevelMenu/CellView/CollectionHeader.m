//
//  CollectionHeader.m
//  ft_procute
//
//  Created by gitBurning on 15/3/18.
//  Copyright (c) 2015年 ft_iem. All rights reserved.
//

#import "CollectionHeader.h"

@implementation CollectionHeader

- (void)awakeFromNib {
    // Initialization code
}

@end
