//
//  HGThirdViewController.h
//  HGPersonalCenter
//
//  Created by Arch on 2017/6/16.
//  Copyright © 2017年 mint_bin. All rights reserved.
//

#import "HGPageViewController.h"

@interface HGThirdViewController : HGPageViewController

@end
