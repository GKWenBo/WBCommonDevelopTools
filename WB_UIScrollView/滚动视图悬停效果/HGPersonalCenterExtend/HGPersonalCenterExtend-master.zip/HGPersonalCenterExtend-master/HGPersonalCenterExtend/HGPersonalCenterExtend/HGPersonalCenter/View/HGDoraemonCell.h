//
//  HGDoraemonCell.h
//  HGPersonalCenterExtend
//
//  Created by Arch on 2018/5/19.
//  Copyright © 2018年 mint_bin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HGDoraemonCell : UITableViewCell

@end
