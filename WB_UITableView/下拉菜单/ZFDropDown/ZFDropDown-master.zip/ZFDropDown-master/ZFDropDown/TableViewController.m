//
//  TableViewController.m
//  ZFDropDown
//
//  Created by Admin on 2017/2/14.
//  Copyright © 2017年 Admin. All rights reserved.
//

#import "TableViewController.h"
#import "DefaultViewController.h"
#import "CustomViewController.h"
@interface TableViewController ()


@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:
        {
            DefaultViewController * vc = [DefaultViewController new];
            [self.navigationController pushViewController:vc animated:YES];
            
        }
            break;
        case 1:
        {
            CustomViewController * vc = [CustomViewController new];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        default:
            break;
    }
}

@end
