//
//  HGSecondViewController.h
//  HGPersonalCenterExtend
//
//  Created by Arch on 2017/6/16.
//  Copyright © 2017年 mint_bin. All rights reserved.
//

#import "HGPageViewController.h"

@interface HGSecondViewController : HGPageViewController

@end
