//
//  HGMessageViewController.m
//  HGPersonalCenterExtend
//
//  Created by Arch on 2017/6/19.
//  Copyright © 2017年 mint_bin. All rights reserved.
//

#import "HGMessageViewController.h"

@implementation HGMessageViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的消息";
}

@end
