//
//  ZFTapGestureRecognizer.h
//  ZFDropDownDemo
//
//  Created by apple on 2017/1/15.
//  Copyright © 2017年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZFTapGestureRecognizer : UITapGestureRecognizer<UIGestureRecognizerDelegate>

@end
