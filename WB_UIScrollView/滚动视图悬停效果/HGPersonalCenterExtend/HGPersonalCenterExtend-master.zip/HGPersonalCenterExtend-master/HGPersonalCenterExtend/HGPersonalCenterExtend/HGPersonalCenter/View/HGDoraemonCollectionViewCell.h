//
//  HGDoraemonCollectionViewCell.h
//  HGPersonalCenterExtend
//
//  Created by Arch on 2019/1/3.
//  Copyright © 2019 mint_bin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HGDoraemonCollectionViewCell : UICollectionViewCell

@end

NS_ASSUME_NONNULL_END
