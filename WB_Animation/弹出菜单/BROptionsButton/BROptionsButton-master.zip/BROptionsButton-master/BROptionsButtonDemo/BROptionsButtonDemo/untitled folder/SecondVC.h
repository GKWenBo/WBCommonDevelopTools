//
//  SecondVC.h
//  BROptionsButtonDemo
//
//  Created by Basheer Malaa on 3/10/14.
//  Copyright (c) 2014 Basheer Malaa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainTabBarController.h"

@interface SecondVC : UIViewController
@property (nonatomic, weak) id<CommonDelegate> commonDelegate;
@end
