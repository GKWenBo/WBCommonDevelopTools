//
//  HGBaseViewController.h
//  HGPersonalCenter
//
//  Created by Arch on 2017/6/19.
//  Copyright © 2017年 mint_bin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HGBaseViewController : UIViewController
@property (nonatomic, strong, readonly) UIView *navigationBar;
@end
