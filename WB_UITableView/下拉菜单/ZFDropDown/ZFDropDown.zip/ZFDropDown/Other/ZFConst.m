//
//  ZFConst.m
//  ZFDropDownDemo
//
//  Created by apple on 2017/1/5.
//  Copyright © 2017年 apple. All rights reserved.
//

#import "ZFConst.h"

CGFloat const NAVIGATIONBAR_HEIGHT = 64.f;
CGFloat const TABBAR_HEIGHT = 49.f;

@implementation ZFConst

@end
