//
//  SJStaticTableViewCell+AccessoryDisclosureIndicator.h
//  SSJStaticTableViewDemo
//
//  Created by Sun Shijie on 2017/3/15.
//  Copyright © 2017年 Shijie. All rights reserved.
//

#import "SJStaticTableViewCell.h"

@interface SJStaticTableViewCell (AccessoryDisclosureIndicator)

- (void)configureAccessoryDisclosureIndicatorCellWithViewModel:(SJStaticTableviewCellViewModel *)viewModel;

@end
