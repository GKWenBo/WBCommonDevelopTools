//
//  ZFView.h
//  ZFDropDownDemo
//
//  Created by apple on 2017/1/5.
//  Copyright © 2017年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZFView : UIView

/** 点击状态 */
@property (nonatomic, assign) BOOL isSelected;

@end
