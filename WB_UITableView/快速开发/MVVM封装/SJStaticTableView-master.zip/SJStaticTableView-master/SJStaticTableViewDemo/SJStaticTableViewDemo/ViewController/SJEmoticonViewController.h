//
//  SJEmoticonViewController.h
//  SJStaticTableViewDemo
//
//  Created by Sun Shijie on 2017/4/22.
//  Copyright © 2017年 Shijie. All rights reserved.
//

#import "SJStaticTableViewController.h"

@interface SJEmoticonViewController : SJStaticTableViewController

@end
