//
//  ViewController.h
//  YCXMenuDemo_ObjC
//
//  Created by 牛萌 on 15/5/6.
//  Copyright (c) 2015年 NiuMeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

