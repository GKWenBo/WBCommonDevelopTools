//
//  CollectionHeader.h
//  ft_procute
//
//  Created by gitBurning on 15/3/18.
//  Copyright (c) 2015年 ft_iem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionHeader : UICollectionReusableView

@property (weak, nonatomic) IBOutlet UILabel *headerTitile;
@end
