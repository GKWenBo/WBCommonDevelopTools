//
//  DefaultViewController.m
//  ZFDropDown
//
//  Created by Admin on 2017/2/14.
//  Copyright © 2017年 Admin. All rights reserved.
//

#import "DefaultViewController.h"
#import "ZFDropDown.h"
@interface DefaultViewController () <ZFDropDownDelegate>

@property (nonatomic,strong) ZFDropDown * dropDown1;
@property (nonatomic,strong) ZFDropDown * dropDown2;
@property (nonatomic,strong) ZFTapGestureRecognizer * tap;
@end

@implementation DefaultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self drop1];
    [self drop2];
    
    self.tap = [[ZFTapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction)];
    [self.view addGestureRecognizer:self.tap];
}

#pragma mark -- dropDown1
#pragma mark
- (void)drop1 {
    self.dropDown1 = [[ZFDropDown alloc]initWithFrame:CGRectMake((SCREEN_WIDTH - 300) / 2, 64 + 10, 300, 40) pattern:kDropDownPatternDefault];
    self.dropDown1.delegate = self;
    //设置自带按钮标题
    [self.dropDown1.topicButton setTitle:@"Please choose 1 continent / area" forState:UIControlStateNormal];
    //设置按钮文字大小
    self.dropDown1.topicButton.titleLabel.font = [UIFont systemFontOfSize:17.f];
    //设置圆角
    self.dropDown1.cornerRadius = 10.f;
    [self.view addSubview:self.dropDown1];
}
- (void)drop2 {
    self.dropDown2 = [[ZFDropDown alloc]initWithFrame:CGRectMake((SCREEN_WIDTH - 300) / 2, 74 + 340, 300, 40) pattern:kDropDownPatternDefault];
    self.dropDown2.delegate = self;
    [self.dropDown2.topicButton setTitle:@"Please choose 1 subject" forState:UIControlStateNormal];
    self.dropDown2.topicButton.titleLabel.font = [UIFont systemFontOfSize:17.f];
    //设置顶部按钮分割线样式
    self.dropDown2.borderStyle = kDropDownTopicBorderStyleRect;
    //设置菜单分割线
    self.dropDown2.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.dropDown2.cellTextFont = [UIFont boldSystemFontOfSize:20.f];
    //设置菜单方向
    self.dropDown2.orientation = kDropDownOrientationUp;
    [self.view addSubview:self.dropDown2];
}

#pragma mark -- <#Your Mark#>
#pragma mark
- (void)tapAction {
    [self.dropDown2 resignDropDownResponder];
    [self.dropDown1 resignDropDownResponder];
}


#pragma mark -- ZFDropDownDelegate
#pragma mark
- (NSArray *)itemArrayInDropDown:(ZFDropDown *)dropDown {
    if (dropDown == self.dropDown1) {
        return @[@"Asia", @"Europe", @"Africa", @"Oceania", @"North America", @"South America", @"Antarctica", @"Arctic"];
    }
    
    return @[@"Chinese", @"Math", @"English", @"Politics", @"Physics", @"Chemistry", @"Geography", @"History", @"Biology", @"Philosophy"];
}
- (NSUInteger)numberOfRowsToDisplayIndropDown:(ZFDropDown *)dropDown itemArrayCount:(NSUInteger)count {
    if (dropDown == self.dropDown1) {
        return 5;
    }
    return 6;
}

@end
